/*
	Copyright (C) 2009-2010 DeSmuME team

	This file is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This file is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with the this software.  If not, see <http://www.gnu.org/licenses/>.
*/


// Author: yolky-nine


#ifndef X432R_BUILDSWITCH_H_INCLUDED
#define X432R_BUILDSWITCH_H_INCLUDED

#include "../types.h"
#include <cmath>


template <typename TYPE>
inline TYPE clamp(const TYPE value, const TYPE min, const TYPE max)
{
	assert(min < max);
	
	if(value < min) return min;
	if(value > max) return max;
	
	return value;
}


// ���𑜓x�����_�����O��L����
#define X432R_CUSTOMRENDERER_ENABLED

// �^�b�`���͊֌W�̕ύX��L����
#define X432R_TOUCHINPUT_ENABLED

// ���j���[�֌W�̕ύX��L����
#define X432R_MENUITEMMOD_ENABLED

// �t�@�C���p�X�֌W�̕ύX��L����
#define X432R_FILEPATHMOD_ENABLED


namespace X432R
{
	//--- ���𑜓x�����_�����O ---
	#ifdef X432R_CUSTOMRENDERER_ENABLED
		#define X432R_OPENGL_FIXEDPOINT_ENABLED			// OpenGL�ɓn���|���S���^�e�N�X�`�����W��GL_FIXED�ɕύX����
		#define X432R_CUSTOMSOFTRASTENGINE_ENABLED		// SoftwareRasterizerEngine�ւ̕ύX��L����
		
//		#define X432R_SINGLECORE_TEST
//		#define X432R_OPENGL_FOG_ENABLED
		#define X432R_INTERFRAMEALPHABLEND_ENABLED
//		#define X432R_SPRITEDETECTION_DEBUG
		
		
		#define X432R_STATIC_RENDER_MAGNIFICATION_CHECK() \
			static_assert( (RENDER_MAGNIFICATION >= 2) && (RENDER_MAGNIFICATION <= 4) , "X432R: invalid rendering magnification")
		
		#define X432R_RENDER_MAGNIFICATION_CHECK() \
			assert( (X432R::renderMagnification >= 1) && (X432R::renderMagnification <= 4) )
		
		
		const s32 spriteDetectionThreshold = 8;
		const s32 highResolution3DResetDelay = 6;
		
		extern u32 renderWidth, renderHeight;
		extern u32 renderMagnification;
		
		u32 *Get3DBackBuffer_HighResolution();
		u32 *Get3DBackBuffer_Downscaled();
		
		
		union ARGB8888
		{
			u32 Color;
			
			#ifdef WORDS_BIGENDIAN
			#else
			struct
			{	u8 B, G, R, A;		};
			#endif
			
			
			ARGB8888()
			{	Color = 0;			}
			
			ARGB8888(u32 color)
			{	Color = color;		}
			
			static inline ARGB8888 AlphaBlend(const ARGB8888 foreground_color, const ARGB8888 background_color)
			{
				if(background_color.A == 0) return foreground_color;
				if(foreground_color.A == 0) return background_color;
				if(foreground_color.A == 0xFF) return foreground_color;
				
				const float foreground_alpha = (float)foreground_color.A / 255.0f;
				const float background_alpha = (float)(0xFF - foreground_color.A) / 255.0f;
				ARGB8888 result;
				
				result.A = 0xFF;
				result.R = (u8)( (foreground_color.R * foreground_alpha) + (background_color.R * background_alpha) );
				result.G = (u8)( (foreground_color.G * foreground_alpha) + (background_color.G * background_alpha) );
				result.B = (u8)( (foreground_color.B * foreground_alpha) + (background_color.B * background_alpha) );
				
				return result;
			}
		};
		
		static inline bool DetectSpritePixel(ARGB8888 framebuffer_color, ARGB8888 downscaled_color)
		{
			if(downscaled_color.A == 0) return true;
			
			downscaled_color.A = 0xFF;
			
			if(framebuffer_color.Color == downscaled_color.Color) return false;
			
			if( abs( (s32)framebuffer_color.R - (s32)downscaled_color.R ) > spriteDetectionThreshold ) return true;
			if( abs( (s32)framebuffer_color.G - (s32)downscaled_color.G ) > spriteDetectionThreshold ) return true;
			if( abs( (s32)framebuffer_color.B - (s32)downscaled_color.B ) > spriteDetectionThreshold ) return true;
			
			return false;
		}
		
		
		#ifdef X432R_INTERFRAMEALPHABLEND_ENABLED
		extern bool interframeAlphaBlendEnabled;
		extern bool interframeAlphaBlendIsWorking;
		extern u32 rawHighResolutionBuffer[2][1024 * 768];
		extern u32 rawHighResolutionBufferCurrentIndex;
		
		void UpdateLastDownscaledBuffer();
		#endif
	#endif
	
	
	//--- ���j���[ ---
	#ifdef X432R_MENUITEMMOD_ENABLED
//		const u32 DWS_NORESIZE = 256;
		extern bool cpuPowerSavingEnabled;
		
		void HK_ToggleSoundEnabledKeyDown(int, bool justPressed);
	#endif
	
	
}

#endif



