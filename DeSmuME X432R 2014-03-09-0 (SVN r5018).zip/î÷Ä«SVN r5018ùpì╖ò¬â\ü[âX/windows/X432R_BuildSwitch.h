/*
	Copyright (C) 2009-2010 DeSmuME team

	This file is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This file is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with the this software.  If not, see <http://www.gnu.org/licenses/>.
*/


// Author: yolky-nine


#ifndef X432R_BUILDSWITCH_H_INCLUDED
#define X432R_BUILDSWITCH_H_INCLUDED

#include "../types.h"


// ���𑜓x�����_�����O��L����
#define X432R_CUSTOMRENDERER_ENABLED

// �^�b�`���͊֌W�̕ύX��L����
#define X432R_TOUCHINPUT_ENABLED

// ���j���[�֌W�̕ύX��L����
#define X432R_MENUITEMMOD_ENABLED

// �t�@�C���p�X�֌W�̕ύX��L����
#define X432R_FILEPATHMOD_ENABLED


namespace X432R
{
	//--- ���𑜓x�����_�����O ---
	#ifdef X432R_CUSTOMRENDERER_ENABLED
		#define X432R_OPENGL_FIXEDPOINT_ENABLED			// OpenGL�ɓn���|���S���^�e�N�X�`�����W��GL_FIXED�ɕύX����
		#define X432R_CUSTOMSOFTRASTENGINE_ENABLED		// SoftwareRasterizerEngine�ւ̕ύX��L����
		#define X432R_NPOTTEXTURE_DISABLED				// X432R::DoDisplay()���ŕ\���ɗp����e�N�X�`���T�C�Y��1024x1024�ɌŒ�
		
//		#define X432R_SINGLECORE_TEST
//		#define X432R_OPENGL_FOG_ENABLED
		
		
		#define X432R_STATIC_RENDER_MAGNIFICATION_CHECK() \
			static_assert( (RENDER_MAGNIFICATION >= 2) && (RENDER_MAGNIFICATION <= 4) , "X432R: invalid rendering magnification")
		
		#define X432R_RENDER_MAGNIFICATION_CHECK() \
			assert( (X432R::renderMagnification >= 1) && (X432R::renderMagnification <= 4) )
		
		extern u32 renderWidth, renderHeight;
		extern u32 renderMagnification;
		
		u32 *Get3DBackBuffer_HighResolution();
		u32 *Get3DBackBuffer_Downscaled();
		void Update3DFrontBuffer();
	#endif
	
	
	//--- ���j���[ ---
	#ifdef X432R_MENUITEMMOD_ENABLED
//		const u32 DWS_NORESIZE = 256;
		extern bool cpuPowerSavingEnabled;
		
		void HK_ToggleSoundEnabledKeyDown(int, bool justPressed);
	#endif
	
	
}


template <typename TYPE>
inline TYPE clamp(const TYPE value, const TYPE min, const TYPE max)
{
	assert(min < max);
	
	if(value < min) return min;
	if(value > max) return max;
	
	return value;
}

/*
template <typename TYPE>
inline void clamp(TYPE &value, const TYPE min, const TYPE max)
{
	assert(min < max);
	
	if(value < min) value = min;
	if(value > max) value = max;
}
*/

#endif



