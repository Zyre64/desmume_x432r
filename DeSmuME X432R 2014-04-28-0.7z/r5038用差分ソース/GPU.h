/*
	Copyright (C) 2006 yopyop
	Copyright (C) 2006-2007 Theo Berkau
	Copyright (C) 2007 shash
	Copyright (C) 2009-2012 DeSmuME team

	This file is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	(at your option) any later version.

	This file is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with the this software.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GPU_H
#define GPU_H

#include <stdio.h>
#include "mem.h"
#include "common.h"
#include "registers.h"
#include "FIFO.h"
#include "MMU.h"
#include <iosfwd>

//#undef FORCEINLINE
//#define FORCEINLINE

void gpu_savestate(EMUFILE* os);
bool gpu_loadstate(EMUFILE* is, int size);

/*******************************************************************************
    this structure is for display control,
    it holds flags for general display
*******************************************************************************/

#ifdef WORDS_BIGENDIAN
struct _DISPCNT
{
/* 7*/  u8 ForceBlank:1;      // A+B:
/* 6*/  u8 OBJ_BMP_mapping:1; // A+B: 0=2D (128KB), 1=1D (128..256KB)
/* 5*/  u8 OBJ_BMP_2D_dim:1;  // A+B: 0=128x512,    1=256x256 pixels
/* 4*/  u8 OBJ_Tile_mapping:1;// A+B: 0=2D (32KB),  1=1D (32..256KB)
/* 3*/  u8 BG0_3D:1;          // A  : 0=2D,         1=3D
/* 0*/  u8 BG_Mode:3;         // A+B:
/*15*/  u8 WinOBJ_Enable:1;   // A+B: 0=disable, 1=Enable
/*14*/  u8 Win1_Enable:1;     // A+B: 0=disable, 1=Enable
/*13*/  u8 Win0_Enable:1;     // A+B: 0=disable, 1=Enable
/*12*/  u8 OBJ_Enable:1;      // A+B: 0=disable, 1=Enable
/*11*/  u8 BG3_Enable:1;      // A+B: 0=disable, 1=Enable
/*10*/  u8 BG2_Enable:1;      // A+B: 0=disable, 1=Enable
/* 9*/  u8 BG1_Enable:1;      // A+B: 0=disable, 1=Enable
/* 8*/  u8 BG0_Enable:1;        // A+B: 0=disable, 1=Enable
/*23*/  u8 OBJ_HBlank_process:1;    // A+B: OBJ processed during HBlank (GBA bit5)
/*22*/  u8 OBJ_BMP_1D_Bound:1;      // A  :
/*20*/  u8 OBJ_Tile_1D_Bound:2;     // A+B:
/*18*/  u8 VRAM_Block:2;            // A  : VRAM block (0..3=A..D)

/*16*/  u8 DisplayMode:2;     // A+B: coreA(0..3) coreB(0..1) GBA(Green Swap)
                                    // 0=off (white screen)
                                    // 1=on (normal BG & OBJ layers)
                                    // 2=VRAM display (coreA only)
                                    // 3=RAM display (coreA only, DMA transfers)

/*31*/  u8 ExOBJPalette_Enable:1;   // A+B: 0=disable, 1=Enable OBJ extended Palette
/*30*/  u8 ExBGxPalette_Enable:1;   // A+B: 0=disable, 1=Enable BG extended Palette
/*27*/  u8 ScreenBase_Block:3;      // A  : Screen Base (64K step)
/*24*/  u8 CharacBase_Block:3;      // A  : Character Base (64K step)
};
#else
struct _DISPCNT
{
/* 0*/  u8 BG_Mode:3;         // A+B:
/* 3*/  u8 BG0_3D:1;          // A  : 0=2D,         1=3D
/* 4*/  u8 OBJ_Tile_mapping:1;     // A+B: 0=2D (32KB),  1=1D (32..256KB)
/* 5*/  u8 OBJ_BMP_2D_dim:1;  // A+B: 0=128x512,    1=256x256 pixels
/* 6*/  u8 OBJ_BMP_mapping:1; // A+B: 0=2D (128KB), 1=1D (128..256KB)

                                    // 7-15 same as GBA
/* 7*/  u8 ForceBlank:1;      // A+B:
/* 8*/  u8 BG0_Enable:1;        // A+B: 0=disable, 1=Enable
/* 9*/  u8 BG1_Enable:1;      // A+B: 0=disable, 1=Enable
/*10*/  u8 BG2_Enable:1;      // A+B: 0=disable, 1=Enable
/*11*/  u8 BG3_Enable:1;      // A+B: 0=disable, 1=Enable
/*12*/  u8 OBJ_Enable:1;      // A+B: 0=disable, 1=Enable
/*13*/  u8 Win0_Enable:1;     // A+B: 0=disable, 1=Enable
/*14*/  u8 Win1_Enable:1;     // A+B: 0=disable, 1=Enable
/*15*/  u8 WinOBJ_Enable:1;   // A+B: 0=disable, 1=Enable

/*16*/  u8 DisplayMode:2;     // A+B: coreA(0..3) coreB(0..1) GBA(Green Swap)
                                    // 0=off (white screen)
                                    // 1=on (normal BG & OBJ layers)
                                    // 2=VRAM display (coreA only)
                                    // 3=RAM display (coreA only, DMA transfers)

/*18*/  u8 VRAM_Block:2;            // A  : VRAM block (0..3=A..D)
/*20*/  u8 OBJ_Tile_1D_Bound:2;     // A+B:
/*22*/  u8 OBJ_BMP_1D_Bound:1;      // A  :
/*23*/  u8 OBJ_HBlank_process:1;    // A+B: OBJ processed during HBlank (GBA bit5)
/*24*/  u8 CharacBase_Block:3;      // A  : Character Base (64K step)
/*27*/  u8 ScreenBase_Block:3;      // A  : Screen Base (64K step)
/*30*/  u8 ExBGxPalette_Enable:1;   // A+B: 0=disable, 1=Enable BG extended Palette
/*31*/  u8 ExOBJPalette_Enable:1;   // A+B: 0=disable, 1=Enable OBJ extended Palette
};
#endif

typedef union
{
    struct _DISPCNT bits;
    u32 val;
} DISPCNT;
#define BGxENABLED(cnt,num)    ((num<8)? ((cnt.val>>8) & num):0)


enum BlendFunc
{
	NoBlend, Blend, Increase, Decrease
};


/*******************************************************************************
    this structure is for display control of a specific layer,
    there are 4 background layers
    their priority indicate which one to draw on top of the other
    some flags indicate special drawing mode, size, FX
*******************************************************************************/

#ifdef WORDS_BIGENDIAN
struct _BGxCNT
{
/* 7*/ u8 Palette_256:1;         // 0=16x16, 1=1*256 palette
/* 6*/ u8 Mosaic_Enable:1;       // 0=disable, 1=Enable mosaic
/* 2*/ u8 CharacBase_Block:4;    // individual character base offset (n*16KB)
/* 0*/ u8 Priority:2;            // 0..3=high..low
/*14*/ u8 ScreenSize:2;          // text    : 256x256 512x256 256x512 512x512
                                       // x/rot/s : 128x128 256x256 512x512 1024x1024
                                       // bmp     : 128x128 256x256 512x256 512x512
                                       // large   : 512x1024 1024x512 - -
/*13*/ u8 PaletteSet_Wrap:1;     // BG0 extended palette set 0=set0, 1=set2
                                       // BG1 extended palette set 0=set1, 1=set3
                                       // BG2 overflow area wraparound 0=off, 1=wrap
                                       // BG3 overflow area wraparound 0=off, 1=wrap
/* 8*/ u8 ScreenBase_Block:5;    // individual screen base offset (text n*2KB, BMP n*16KB)
};
#else
struct _BGxCNT
{
/* 0*/ u8 Priority:2;            // 0..3=high..low
/* 2*/ u8 CharacBase_Block:4;    // individual character base offset (n*16KB)
/* 6*/ u8 Mosaic_Enable:1;       // 0=disable, 1=Enable mosaic
/* 7*/ u8 Palette_256:1;         // 0=16x16, 1=1*256 palette
/* 8*/ u8 ScreenBase_Block:5;    // individual screen base offset (text n*2KB, BMP n*16KB)
/*13*/ u8 PaletteSet_Wrap:1;     // BG0 extended palette set 0=set0, 1=set2
                                       // BG1 extended palette set 0=set1, 1=set3
                                       // BG2 overflow area wraparound 0=off, 1=wrap
                                       // BG3 overflow area wraparound 0=off, 1=wrap
/*14*/ u8 ScreenSize:2;          // text    : 256x256 512x256 256x512 512x512
                                       // x/rot/s : 128x128 256x256 512x512 1024x1024
                                       // bmp     : 128x128 256x256 512x256 512x512
                                       // large   : 512x1024 1024x512 - -
};
#endif


typedef union
{
    struct _BGxCNT bits;
    u16 val;
} BGxCNT;

/*******************************************************************************
    this structure is for background offset
*******************************************************************************/

typedef struct {
    u16 BGxHOFS;
    u16 BGxVOFS;
} BGxOFS;

/*******************************************************************************
    this structure is for rotoscale parameters
*******************************************************************************/

typedef struct {
    s16 BGxPA;
    s16 BGxPB;
    s16 BGxPC;
    s16 BGxPD;
    s32 BGxX;
    s32 BGxY;
} BGxPARMS;


/*******************************************************************************
	these structures are for window description,
	windows are square regions and can "subclass"
	background layers or object layers (i.e window controls the layers)

	screen
	|
	+-- Window0/Window1/OBJwindow/OutOfWindows
		|
		+-- BG0/BG1/BG2/BG3/OBJ
*******************************************************************************/

typedef union {
	struct	{
		u8 end:8;
		u8 start:8;
	} bits ;
	u16 val;
} WINxDIM;

#ifdef WORDS_BIGENDIAN
typedef struct {
/* 6*/  u8 :2;
/* 5*/  u8 WINx_Effect_Enable:1;
/* 4*/  u8 WINx_OBJ_Enable:1;
/* 3*/  u8 WINx_BG3_Enable:1;
/* 2*/  u8 WINx_BG2_Enable:1;
/* 1*/  u8 WINx_BG1_Enable:1;
/* 0*/  u8 WINx_BG0_Enable:1;
} WINxBIT;
#else
typedef struct {
/* 0*/  u8 WINx_BG0_Enable:1;
/* 1*/  u8 WINx_BG1_Enable:1;
/* 2*/  u8 WINx_BG2_Enable:1;
/* 3*/  u8 WINx_BG3_Enable:1;
/* 4*/  u8 WINx_OBJ_Enable:1;
/* 5*/  u8 WINx_Effect_Enable:1;
/* 6*/  u8 :2;
} WINxBIT;
#endif

#ifdef WORDS_BIGENDIAN
typedef union {
	struct {
		WINxBIT win0;
		WINxBIT win1;
	} bits;
	struct {
		u8 :3;
		u8 win0_en:5;
		u8 :3;
		u8 win1_en:5;
	} packed_bits;
	struct {
		u8 low;
		u8 high;
	} bytes;
	u16 val ;
} WINxCNT ;
#else
typedef union {
	struct {
		WINxBIT win0;
		WINxBIT win1;
	} bits;
	struct {
		u8 win0_en:5;
		u8 :3;
		u8 win1_en:5;
		u8 :3;
	} packed_bits;
	struct {
		u8 low;
		u8 high;
	} bytes;
	u16 val ;
} WINxCNT ;
#endif

/*
typedef struct {
    WINxDIM WIN0H;
    WINxDIM WIN1H;
    WINxDIM WIN0V;
    WINxDIM WIN1V;
    WINxCNT WININ;
    WINxCNT WINOUT;
} WINCNT;
*/

/*******************************************************************************
    this structure is for miscellanous settings
    //TODO: needs further description
*******************************************************************************/

typedef struct {
    u16 MOSAIC;
    u16 unused1;
    u16 unused2;//BLDCNT;
    u16 unused3;//BLDALPHA;
    u16 unused4;//BLDY;
    u16 unused5;
	/*
    u16 unused6;
    u16 unused7;
    u16 unused8;
    u16 unused9;
	*/
} MISCCNT;


/*******************************************************************************
    this structure is for 3D settings
*******************************************************************************/

struct _DISP3DCNT
{
/* 0*/ u8 EnableTexMapping:1;    //
/* 1*/ u8 PolygonShading:1;      // 0=Toon Shading, 1=Highlight Shading
/* 2*/ u8 EnableAlphaTest:1;     // see ALPHA_TEST_REF
/* 3*/ u8 EnableAlphaBlending:1; // see various Alpha values
/* 4*/ u8 EnableAntiAliasing:1;  //
/* 5*/ u8 EnableEdgeMarking:1;   // see EDGE_COLOR
/* 6*/ u8 FogOnlyAlpha:1;        // 0=Alpha and Color, 1=Only Alpha (see FOG_COLOR)
/* 7*/ u8 EnableFog:1;           // Fog Master Enable
/* 8*/ u8 FogShiftSHR:4;         // 0..10 SHR-Divider (see FOG_OFFSET)
/*12*/ u8 AckColorBufferUnderflow:1; // Color Buffer RDLINES Underflow (0=None, 1=Underflow/Acknowledge)
/*13*/ u8 AckVertexRAMOverflow:1;    // Polygon/Vertex RAM Overflow    (0=None, 1=Overflow/Acknowledge)
/*14*/ u8 RearPlaneMode:1;       // 0=Blank, 1=Bitmap
/*15*/ u8 :1;
/*16*/ u16 :16;
};

typedef union
{
    struct _DISP3DCNT bits;
    u32 val;
} DISP3DCNT;

/*******************************************************************************
    this structure is for capture control (core A only)

    source:
    http://nocash.emubase.de/gbatek.htm#dsvideocaptureandmainmemorydisplaymode
*******************************************************************************/
struct DISPCAPCNT
{
	enum CAPX {
		_128, _256
	} capx;
    u32 val;
	BOOL enabled;
	u8 EVA;
	u8 EVB;
	u8 writeBlock;
	u8 writeOffset;
	u16 capy;
	u8 srcA;
	u8 srcB;
	u8 readBlock;
	u8 readOffset;
	u8 capSrc;
} ;

/*******************************************************************************
    this structure holds everything and should be mapped to
    * core A : 0x04000000
    * core B : 0x04001000
*******************************************************************************/

typedef struct _reg_dispx {
    DISPCNT dispx_DISPCNT;            // 0x0400x000
    u16 dispA_DISPSTAT;               // 0x04000004
    u16 dispx_VCOUNT;                 // 0x0400x006
    BGxCNT dispx_BGxCNT[4];           // 0x0400x008
    BGxOFS dispx_BGxOFS[4];           // 0x0400x010
    BGxPARMS dispx_BG2PARMS;          // 0x0400x020
    BGxPARMS dispx_BG3PARMS;          // 0x0400x030
    u8			filler[12];           // 0x0400x040
    MISCCNT dispx_MISC;               // 0x0400x04C
    DISP3DCNT dispA_DISP3DCNT;        // 0x04000060
    DISPCAPCNT dispA_DISPCAPCNT;      // 0x04000064
    u32 dispA_DISPMMEMFIFO;           // 0x04000068
} REG_DISPx ;


typedef BOOL (*fun_gl_Begin) (int screen);
typedef void (*fun_gl_End) (int screen);
// the GUI should use this function prior to all gl calls
// if call to beg succeeds opengl draw
void register_gl_fun(fun_gl_Begin beg,fun_gl_End end);

#define GPU_MAIN	0
#define GPU_SUB		1

/* human readable bitmask names */
#define ADDRESS_STEP_512B	   0x00200
#define ADDRESS_STEP_1KB		0x00400
#define ADDRESS_STEP_2KB		0x00800
#define ADDRESS_STEP_4KB		0x01000
#define ADDRESS_STEP_8KB		0x02000
#define ADDRESS_STEP_16KB	   0x04000
#define ADDRESS_STEP_32KB	   0x08000
#define ADDRESS_STEP_64KB	   0x10000
#define ADDRESS_STEP_128KB	   0x20000
#define ADDRESS_STEP_256KB	   0x40000
#define ADDRESS_STEP_512KB	   0x80000
#define ADDRESS_MASK_256KB	   (ADDRESS_STEP_256KB-1)

#ifdef WORDS_BIGENDIAN
struct _TILEENTRY
{
/*14*/	unsigned Palette:4;
/*13*/	unsigned VFlip:1;	// VERTICAL FLIP (top<-->bottom)
/*12*/	unsigned HFlip:1;	// HORIZONTAL FLIP (left<-->right)
/* 0*/	unsigned TileNum:10;
};
#else
struct _TILEENTRY
{
/* 0*/	unsigned TileNum:10;
/*12*/	unsigned HFlip:1;	// HORIZONTAL FLIP (left<-->right)
/*13*/	unsigned VFlip:1;	// VERTICAL FLIP (top<-->bottom)
/*14*/	unsigned Palette:4;
};
#endif
typedef union
{
	struct _TILEENTRY bits;
	u16 val;
} TILEENTRY;

struct _ROTOCOORD
{
	u32 Fraction:8;
	s32 Integer:20;
	u32 pad:4;
};
typedef union
{
	struct _ROTOCOORD bits;
	s32 val;
} ROTOCOORD;


/*
	this structure is for color representation,
	it holds 5 meaningful bits per color channel (red,green,blue)
	and	  1 meaningful bit for alpha representation
	this bit can be unused or used for special FX
*/

struct _COLOR { // abgr x555
#ifdef WORDS_BIGENDIAN
	unsigned alpha:1;    // sometimes it is unused (pad)
	unsigned blue:5;
	unsigned green:5;
	unsigned red:5;
#else
     unsigned red:5;
     unsigned green:5;
     unsigned blue:5;
     unsigned alpha:1;    // sometimes it is unused (pad)
#endif
};
struct _COLORx { // abgr x555
	unsigned bgr:15;
	unsigned alpha:1;	// sometimes it is unused (pad)
};

typedef union
{
	struct _COLOR bits;
	struct _COLORx bitx;
	u16 val;
} COLOR;

struct _COLOR32 { // ARGB
	unsigned :3;
	unsigned blue:5;
	unsigned :3;
	unsigned green:5;
	unsigned :3;
	unsigned red:5;
	unsigned :7;
	unsigned alpha:1;	// sometimes it is unused (pad)
};

typedef union
{
	struct _COLOR32 bits;
	u32 val;
} COLOR32;

#define COLOR_16_32(w,i)	\
	/* doesnt matter who's 16bit who's 32bit */ \
	i.bits.red   = w.bits.red; \
	i.bits.green = w.bits.green; \
	i.bits.blue  = w.bits.blue; \
	i.bits.alpha = w.bits.alpha;



 // (00: Normal, 01: Transparent, 10: Object window, 11: Bitmap)
enum GPU_OBJ_MODE
{
	GPU_OBJ_MODE_Normal = 0,
	GPU_OBJ_MODE_Transparent = 1,
	GPU_OBJ_MODE_Window = 2,
	GPU_OBJ_MODE_Bitmap = 3
};

struct _OAM_
{
	//attr0
	u8 Y;
	u8 RotScale;
	u8 Mode;
	u8 Mosaic;
	u8 Depth;
	u8 Shape;
	//att1
	s16 X;
	u8 RotScalIndex;
	u8 HFlip, VFlip;
	u8 Size;
	//attr2
	u16 TileIndex;
	u8 Priority;
	u8 PaletteIndex;
	//attr3
	u16 attr3;
};

void SlurpOAM(_OAM_* oam_output, void* oam_buffer, int oam_index);
u16 SlurpOAMAffineParam(void* oam_buffer, int oam_index);

typedef struct
{
	 s16 x;
	 s16 y;
} size;


#define NB_PRIORITIES	4
#define NB_BG		4
//this structure holds information for rendering.
typedef struct
{
	u8 PixelsX[256];
	u8 BGs[NB_BG], nbBGs;
	u8 pad[1];
	u16 nbPixelsX;
	//256+8:
	u8 pad2[248];

	//things were slower when i organized this struct this way. whatever.
	//u8 PixelsX[256];
	//int BGs[NB_BG], nbBGs;
	//int nbPixelsX;
	////<-- 256 + 24
	//u8 pad2[256-24];
} itemsForPriority_t;
#define MMU_ABG		0x06000000
#define MMU_BBG		0x06200000
#define MMU_AOBJ	0x06400000
#define MMU_BOBJ	0x06600000
#define MMU_LCDC	0x06800000

extern CACHE_ALIGN u8 gpuBlendTable555[17][17][32][32];

enum BGType {
	BGType_Invalid=0, BGType_Text=1, BGType_Affine=2, BGType_Large8bpp=3, 
	BGType_AffineExt=4, BGType_AffineExt_256x16=5, BGType_AffineExt_256x1=6, BGType_AffineExt_Direct=7
};

extern const BGType GPU_mode2type[8][4];

struct GPU
{
	GPU()
		: debug(false)
	{}

	// some structs are becoming redundant
	// some functions too (no need to recopy some vars as it is done by MMU)
	REG_DISPx * dispx_st;

	//this indicates whether this gpu is handling debug tools
	bool debug;

	_BGxCNT & bgcnt(int num) { return (dispx_st)->dispx_BGxCNT[num].bits; }
	_DISPCNT & dispCnt() { return dispx_st->dispx_DISPCNT.bits; }
	template<bool MOSAIC> void modeRender(int layer);

	DISPCAPCNT dispCapCnt;
	BOOL LayersEnable[5];
	itemsForPriority_t itemsForPriority[NB_PRIORITIES];

#define BGBmpBB BG_bmp_ram
#define BGChBB BG_tile_ram

	u32 BG_bmp_large_ram[4];
	u32 BG_bmp_ram[4];
	u32 BG_tile_ram[4];
	u32 BG_map_ram[4];

	u8 BGExtPalSlot[4];
	u32 BGSize[4][2];
	BGType BGTypes[4];

	struct MosaicColor {
		u16 bg[4][256];
		struct Obj {
			u16 color;
			u8 alpha, opaque;
		} obj[256];
	} mosaicColors;

	u8 sprNum[256];
	u8 h_win[2][256];
	const u8 *curr_win[2];
	void update_winh(int WIN_NUM); 
	bool need_update_winh[2];
	
	template<int WIN_NUM> void setup_windows();

	u8 core;

	u8 dispMode;
	u8 vramBlock;
	u8 *VRAMaddr;

	//FIFO	fifo;

	u8 bgPrio[5];

	BOOL bg0HasHighestPrio;

	void * oam;
	u32	sprMem;
	u8 sprBoundary;
	u8 sprBMPBoundary;
	u8 sprBMPMode;
	u32 sprEnable;

	u8 WIN0H0;
	u8 WIN0H1;
	u8 WIN0V0;
	u8 WIN0V1;

	u8 WIN1H0;
	u8 WIN1H1;
	u8 WIN1V0;
	u8 WIN1V1;

	u8 WININ0;
	bool WININ0_SPECIAL;
	u8 WININ1;
	bool WININ1_SPECIAL;

	u8 WINOUT;
	bool WINOUT_SPECIAL;
	u8 WINOBJ;
	bool WINOBJ_SPECIAL;

	u8 WIN0_ENABLED;
	u8 WIN1_ENABLED;
	u8 WINOBJ_ENABLED;

	u16 BLDCNT;
	u8	BLDALPHA_EVA;
	u8	BLDALPHA_EVB;
	u8	BLDY_EVY;
	u16 *currentFadeInColors, *currentFadeOutColors;
	bool blend2[8];

	CACHE_ALIGN u16 tempScanlineBuffer[256];
	u8 *tempScanline;

	u8	MasterBrightMode;
	u32 MasterBrightFactor;

	CACHE_ALIGN u8 bgPixels[1024]; //yes indeed, this is oversized. map debug tools try to write to it

	u32 currLine;
	u8 currBgNum;
	bool blend1;
	u8* currDst;

	u8* _3dColorLine;


	static struct MosaicLookup {

		struct TableEntry {
			u8 begin, trunc;
		} table[16][256];

		MosaicLookup() {
			for(int m=0;m<16;m++)
				for(int i=0;i<256;i++) {
					int mosaic = m+1;
					TableEntry &te = table[m][i];
					te.begin = (i%mosaic==0);
					te.trunc = i/mosaic*mosaic;
				}
		}

		TableEntry *width, *height;
		int widthValue, heightValue;
		
	} mosaicLookup;
	bool curr_mosaic_enabled;

	u16 blend(u16 colA, u16 colB);

	template<bool BACKDROP, BlendFunc FUNC, bool WINDOW>
	FORCEINLINE FASTCALL bool _master_setFinalBGColor(u16 &color, const u32 x);

	template<BlendFunc FUNC, bool WINDOW>
	FORCEINLINE FASTCALL void _master_setFinal3dColor(int dstX, int srcX);

	int setFinalColorBck_funcNum;
	int bgFunc;
	int setFinalColor3d_funcNum;
	int setFinalColorSpr_funcNum;
	//Final3DColFunct setFinalColor3D;
	enum SpriteRenderMode {
		SPRITE_1D, SPRITE_2D
	} spriteRenderMode;

	template<GPU::SpriteRenderMode MODE>
	void _spriteRender(u8 * dst, u8 * dst_alpha, u8 * typeTab, u8 * prioTab);
	
	inline void spriteRender(u8 * dst, u8 * dst_alpha, u8 * typeTab, u8 * prioTab)
	{
		if(spriteRenderMode == SPRITE_1D)
			_spriteRender<SPRITE_1D>(dst,dst_alpha,typeTab, prioTab);
		else
			_spriteRender<SPRITE_2D>(dst,dst_alpha,typeTab, prioTab);
	}


	void setFinalColor3d(int dstX, int srcX);
	
	template<bool BACKDROP, int FUNCNUM> void setFinalColorBG(u16 color, const u32 x);
	template<bool MOSAIC, bool BACKDROP> FORCEINLINE void __setFinalColorBck(u16 color, const u32 x, const int opaque);
	template<bool MOSAIC, bool BACKDROP, int FUNCNUM> FORCEINLINE void ___setFinalColorBck(u16 color, const u32 x, const int opaque);

	void setAffineStart(int layer, int xy, u32 val);
	void setAffineStartWord(int layer, int xy, u16 val, int word);
	u32 getAffineStart(int layer, int xy);
	void refreshAffineStartRegs(const int num, const int xy);

	struct AffineInfo {
		AffineInfo() : x(0), y(0) {}
		u32 x, y;
	} affineInfo[2];

	void renderline_checkWindows(u16 x, bool &draw, bool &effect) const;

	// check whether (x,y) is within the rectangle (including wraparounds) 
	template<int WIN_NUM>
	u8 withinRect(u16 x) const;

	void setBLDALPHA(u16 val)
	{
		BLDALPHA_EVA = (val&0x1f) > 16 ? 16 : (val&0x1f); 
		BLDALPHA_EVB = ((val>>8)&0x1f) > 16 ? 16 : ((val>>8)&0x1f);
		updateBLDALPHA();
	}

	void setBLDALPHA_EVA(u8 val)
	{
		BLDALPHA_EVA = (val&0x1f) > 16 ? 16 : (val&0x1f);
		updateBLDALPHA();
	}
	
	void setBLDALPHA_EVB(u8 val)
	{
		BLDALPHA_EVB = (val&0x1f) > 16 ? 16 : (val&0x1f);
		updateBLDALPHA();
	}

	u32 getHOFS(int bg) { return T1ReadWord(&dispx_st->dispx_BGxOFS[bg].BGxHOFS,0) & 0x1FF; }
	u32 getVOFS(int bg) { return T1ReadWord(&dispx_st->dispx_BGxOFS[bg].BGxVOFS,0) & 0x1FF; }

	typedef u8 TBlendTable[32][32];
	TBlendTable *blendTable;

	void updateBLDALPHA()
	{
		blendTable = (TBlendTable*)&gpuBlendTable555[BLDALPHA_EVA][BLDALPHA_EVB][0][0];
	}
	
};
#if 0
// normally should have same addresses
static void REG_DISPx_pack_test(GPU * gpu)
{
	REG_DISPx * r = gpu->dispx_st;
	printf ("%08x %02x\n",  (u32)r, (u32)(&r->dispx_DISPCNT) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispA_DISPSTAT) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispx_VCOUNT) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispx_BGxCNT[0]) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispx_BGxOFS[0]) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispx_BG2PARMS) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispx_BG3PARMS) - (u32)r);
//	printf ("\t%02x\n", (u32)(&r->dispx_WINCNT) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispx_MISC) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispA_DISP3DCNT) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispA_DISPCAPCNT) - (u32)r);
	printf ("\t%02x\n", (u32)(&r->dispA_DISPMMEMFIFO) - (u32)r);
}
#endif

CACHE_ALIGN extern u8 GPU_screen[4*256*192];


GPU * GPU_Init(u8 l);
void GPU_Reset(GPU *g, u8 l);
void GPU_DeInit(GPU *);

//these are functions used by debug tools which want to render layers etc outside the context of the emulation
namespace GPU_EXT
{
	void textBG(GPU * gpu, u8 num, u8 * DST);		//Draw text based background
	void rotBG(GPU * gpu, u8 num, u8 * DST);
	void extRotBG(GPU * gpu, u8 num, u8 * DST);
};
void sprite1D(GPU * gpu, u16 l, u8 * dst, u8 * dst_alpha, u8 * typeTab, u8 * prioTab);
void sprite2D(GPU * gpu, u16 l, u8 * dst, u8 * dst_alpha, u8 * typeTab, u8 * prioTab);

extern const size sprSizeTab[4][4];

typedef struct {
	GPU * gpu;
	u16 offset;
} NDS_Screen;

extern NDS_Screen MainScreen;
extern NDS_Screen SubScreen;

int Screen_Init();
void Screen_Reset(void);
void Screen_DeInit(void);

extern MMU_struct MMU;

void GPU_setVideoProp(GPU *, u32 p);
void GPU_setBGProp(GPU *, u16 num, u16 p);

void GPU_setBLDCNT(GPU *gpu, u16 v) ;
void GPU_setBLDY(GPU *gpu, u16 v) ;
void GPU_setMOSAIC(GPU *gpu, u16 v) ;


void GPU_remove(GPU *, u8 num);
void GPU_addBack(GPU *, u8 num);

int GPU_ChangeGraphicsCore(int coreid);

void GPU_set_DISPCAPCNT(u32 val) ;
void GPU_RenderLine(NDS_Screen * screen, u16 l, bool skip = false) ;
void GPU_setMasterBrightness (GPU *gpu, u16 val);

inline void GPU_setWIN0_H(GPU* gpu, u16 val) { gpu->WIN0H0 = val >> 8; gpu->WIN0H1 = val&0xFF; gpu->need_update_winh[0] = true; }
inline void GPU_setWIN0_H0(GPU* gpu, u8 val) { gpu->WIN0H0 = val;  gpu->need_update_winh[0] = true; }
inline void GPU_setWIN0_H1(GPU* gpu, u8 val) { gpu->WIN0H1 = val;  gpu->need_update_winh[0] = true; }

inline void GPU_setWIN0_V(GPU* gpu, u16 val) { gpu->WIN0V0 = val >> 8; gpu->WIN0V1 = val&0xFF;}
inline void GPU_setWIN0_V0(GPU* gpu, u8 val) { gpu->WIN0V0 = val; }
inline void GPU_setWIN0_V1(GPU* gpu, u8 val) { gpu->WIN0V1 = val; }

inline void GPU_setWIN1_H(GPU* gpu, u16 val) {gpu->WIN1H0 = val >> 8; gpu->WIN1H1 = val&0xFF;  gpu->need_update_winh[1] = true; }
inline void GPU_setWIN1_H0(GPU* gpu, u8 val) { gpu->WIN1H0 = val;  gpu->need_update_winh[1] = true; }
inline void GPU_setWIN1_H1(GPU* gpu, u8 val) { gpu->WIN1H1 = val;  gpu->need_update_winh[1] = true; }

inline void GPU_setWIN1_V(GPU* gpu, u16 val) { gpu->WIN1V0 = val >> 8; gpu->WIN1V1 = val&0xFF; }
inline void GPU_setWIN1_V0(GPU* gpu, u8 val) { gpu->WIN1V0 = val; }
inline void GPU_setWIN1_V1(GPU* gpu, u8 val) { gpu->WIN1V1 = val; }

inline void GPU_setWININ(GPU* gpu, u16 val) {
	gpu->WININ0=val&0x1F;
	gpu->WININ0_SPECIAL=((val>>5)&1)!=0;
	gpu->WININ1=(val>>8)&0x1F;
	gpu->WININ1_SPECIAL=((val>>13)&1)!=0;
}

inline void GPU_setWININ0(GPU* gpu, u8 val) { gpu->WININ0 = val&0x1F; gpu->WININ0_SPECIAL = (val>>5)&1; }
inline void GPU_setWININ1(GPU* gpu, u8 val) { gpu->WININ1 = val&0x1F; gpu->WININ1_SPECIAL = (val>>5)&1; }

inline void GPU_setWINOUT16(GPU* gpu, u16 val) {
	gpu->WINOUT=val&0x1F;
	gpu->WINOUT_SPECIAL=((val>>5)&1)!=0;
	gpu->WINOBJ=(val>>8)&0x1F;
	gpu->WINOBJ_SPECIAL=((val>>13)&1)!=0;
}
inline void GPU_setWINOUT(GPU* gpu, u8 val) { gpu->WINOUT = val&0x1F; gpu->WINOUT_SPECIAL = (val>>5)&1; }
inline void GPU_setWINOBJ(GPU* gpu, u8 val) { gpu->WINOBJ = val&0x1F; gpu->WINOBJ_SPECIAL = (val>>5)&1; }

// Blending
void SetupFinalPixelBlitter (GPU *gpu);
#define GPU_setBLDCNT_LOW(gpu, val) {gpu->BLDCNT = (gpu->BLDCNT&0xFF00) | (val); SetupFinalPixelBlitter (gpu);}
#define GPU_setBLDCNT_HIGH(gpu, val) {gpu->BLDCNT = (gpu->BLDCNT&0xFF) | (val<<8); SetupFinalPixelBlitter (gpu);}
#define GPU_setBLDCNT(gpu, val) {gpu->BLDCNT = (val); SetupFinalPixelBlitter (gpu);}



#define GPU_setBLDY_EVY(gpu, val) {gpu->BLDY_EVY = ((val)&0x1f) > 16 ? 16 : ((val)&0x1f);}

//these arent needed right now since the values get poked into memory via default mmu handling and dispx_st
//#define GPU_setBGxHOFS(bg, gpu, val) gpu->dispx_st->dispx_BGxOFS[bg].BGxHOFS = ((val) & 0x1FF)
//#define GPU_setBGxVOFS(bg, gpu, val) gpu->dispx_st->dispx_BGxOFS[bg].BGxVOFS = ((val) & 0x1FF)

void gpu_SetRotateScreen(u16 angle);

//#undef FORCEINLINE
//#define FORCEINLINE __forceinline



//---CUSTOM--->
#include "X432R_BuildSwitch.h"
#include <map>
#include <utility>

#ifdef X432R_CUSTOMRENDERER_ENABLED
namespace X432R
{
	union RGBA8888
	{
		u32 Color;
		
		#ifdef WORDS_BIGENDIAN
		// todo
		#else
		struct
		{	u8 B, G, R, A;		};
		#endif
		
		
		RGBA8888()
		{	Color = 0;			}
		
		RGBA8888(const u32 color)
		{	Color = color;		}
		
		
		static inline u16 ToRGB555(RGBA8888 color)
		{
			if(color.A == 0) return 0;
				
			#ifdef WORDS_BIGENDIAN
			// todo
			#else
			return ( ( (u16)(color.B >> 3) << 10 ) | ( (u16)(color.G >> 3) << 5 ) | (u16)(color.R >> 3) );
			#endif
		}
		
		static inline RGBA8888 AlphaBlend(RGBA8888 foreground_color, RGBA8888 background_color)
		{
			if(( foreground_color.A == 0) && (background_color.A == 0) ) return 0;
			
			if(foreground_color.A == 0xFF)
				return foreground_color;
			
			if(foreground_color.A == 0)
			{
//					background_color.A = 0xFF;
				return background_color;
			}
			
			if(background_color.A == 0)
			{
//					foreground_color.A = 0xFF;
				return foreground_color;
			}
			
			RGBA8888 result;
			
			#if 1
			const float foreground_alpha = (float)foreground_color.A / 255.0f;
			const float background_alpha = (float)(0xFF - foreground_color.A) / 255.0f;
			
			result.A = 0xFF;
			result.R = (u8)( (foreground_color.R * foreground_alpha) + (background_color.R * background_alpha) );
			result.G = (u8)( (foreground_color.G * foreground_alpha) + (background_color.G * background_alpha) );
			result.B = (u8)( (foreground_color.B * foreground_alpha) + (background_color.B * background_alpha) );
			#else
			// Q16�̌Œ菬���_���Ōv�Z
			const u32 foreground_alpha = (foreground_color.A + 1) << 8;
			const u32 background_alpha = (0x100 - foreground_color.A) << 8;
			
			result.A = 0xFF;
			result.R = (u8)std::min<u32>( ( ( (u32)foreground_color.R * foreground_alpha ) + ( (u32)background_color.R * background_alpha ) ) >> 16, 0xFF );
			result.G = (u8)std::min<u32>( ( ( (u32)foreground_color.G * foreground_alpha ) + ( (u32)background_color.G * background_alpha ) ) >> 16, 0xFF );
			result.B = (u8)std::min<u32>( ( ( (u32)foreground_color.B * foreground_alpha ) + ( (u32)background_color.B * background_alpha ) ) >> 16, 0xFF );
			#endif
			
			return result;
		}
		
		static inline RGBA8888 AlphaBlend(RGBA8888 color1, RGBA8888 color2, u8 alpha1)
		{
			if( (color1.A == 0) && (color2.A == 0) ) return 0;
			
			if(alpha1 == 0xFF)
				return color1;
			
			if(alpha1 == 0)
				return color2;
			
			#if 1
			const float a1 = (float)alpha1 / 255.0f;
			
			if(color2.A == 0)
			{
				color1.A *= a1;
				return color1;
			}
			
			const float a2 = (float)(0xFF - alpha1) / 255.0f;
			
			if(color1.A == 0)
			{
				color2.A *= a2;
				return color2;
			}
			
			RGBA8888 result;
			
			result.A = 0xFF;
			result.R = (u8)( (color1.R * a1) + (color2.R * a2) );
			result.G = (u8)( (color1.G * a1) + (color2.G * a2) );
			result.B = (u8)( (color1.B * a1) + (color2.B * a2) );
			#else
			// Q16�̌Œ菬���_���Ōv�Z
			const u32 a1 = (alpha1 + 1) << 8;
			
			if(color2.A == 0)
			{
				color1.A = (u8)std::min<u32>( ( (u32)color1.A * a1 ) >> 16, 0xFF );
				return color1;
			}
			
			const u32 a2 = (0x100 - alpha1) << 8;
			
			if(color1.A == 0)
			{
				color2.A = (u8)std::min<u32>( ( (u32)color2.A * a2 ) >> 16, 0xFF );
				return color2;
			}
			
			RGBA8888 result;
			
			result.A = 0xFF;
			result.R = (u8)std::min<u32>( ( ( (u32)color1.R * a1 ) + ( (u32)color2.R * a2 ) ) >> 16, 0xFF );
			result.G = (u8)std::min<u32>( ( ( (u32)color1.G * a1 ) + ( (u32)color2.G * a2 ) ) >> 16, 0xFF );
			result.B = (u8)std::min<u32>( ( ( (u32)color1.B * a1 ) + ( (u32)color2.B * a2 ) ) >> 16, 0xFF );
			#endif
			
			return result;
		}
	};
	
	
	class HighResolutionFramebuffers
	{
		public:
		
		#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
		static const s32 BufferResetDelay_MainGpu = 10;
		#endif
		#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
		static const s32 BufferResetDelay_Vram = 10;
		#endif
		static const s32 BufferResetDelay_FastForward = 20;
		
		u32 MainGpuHighResolutionBuffer[1024 * 768];
		#ifndef X432R_SIMPLIFIED_SPRITEDETECTION
		u16 MainGpuDownscaledBuffer[256 * 192];
		#endif
		u32 BackgroundBuffer[2][256 * 192];
		u32 ForegroundBuffer[2][256 * 192];
		#ifndef X432R_LAYERNUMBUFFER_DISABLED
		u8 LayerNumBuffer[2][256 * 192];
		u8 PriorityBuffer[2][256 * 192];
		#endif
		
		u32 VramHighResolutionBuffer[4][1024 * 768];
		#ifndef X432R_SIMPLIFIED_SPRITEDETECTION
		u16 VramDownscaledBuffer[4][256 * 192];
		#endif
		#ifndef X432R_NEW_DISPCAPTURE_TEST
		u32 VramBackgroundBuffer[4][256 * 192];
		u32 VramForegroundBuffer[4][256 * 192];
		#endif
		
		u8 MainScreenIndex;
		u8 SubScreenIndex;
		u8 MainGpuDisplayMode;
		u32 MainGpuClearColor;
		_DISPCNT DisplayControl[2];
//		bool MainGpuBG03DEnabled;
		DISPCAPCNT MainGpuDisplayCapture;
		u8 DisplayCaptureBlendingRatio;
		
		VramConfiguration::Purpose VramPurpose[4];
		bool VramIsValid[4];
		#ifndef X432R_NEW_DISPCAPTURE_TEST
		bool VramContains2DData[4];
//		u8 Vram3DOpacity[4];
		#endif
		
		u8 VramBlockMainScreen;
		u8 VramBlockBG[2];
		u8 VramBlockOBJ[2];
		u8 VramAssignedBGNum[2];
		u8 VramAssignedOBJPriority[2];
		
		s32 MasterBrightness[2];
		u8 LayerPriority[2][4];
		
		u32 PolygonCount;
		
		#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
		s32 MainGpuUnupdatedFrameCount;
		#endif
		#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
		s32 VramUnupdatedFrameCount[4];
		#endif
		
		bool ExistsMainGpuBG03D;
		bool ExistsVramAssignedBG[2];
		bool ExistsVramAssignedOBJ[2];
		
//		u32 LayerHorizontalOffset[2][4];
//		u32 LayerVerticalOffset[2][4];
		
		
		private:
		
		bool UpdateVramAssignedBGNum(const _DISPCNT * const display_control, const u8 screen_index)
		{
			assert( (screen_index == 0) || (screen_index == 1) );
			
			// VRAM ABG�^BBG��BG2�^BG3�ɂ̂݊��蓖�Ă��邱�Ƃ�O��Ƃ��Ă���
			if( !(bool)display_control->BG2_Enable && !(bool)display_control->BG3_Enable )
			{
				VramAssignedBGNum[screen_index] = 0xFF;
				return true;
			}
			
			if( (bool)display_control->BG2_Enable && !(bool)display_control->BG3_Enable )
				VramAssignedBGNum[screen_index] = 2;
			
			else if( !(bool)display_control->BG2_Enable && (bool)display_control->BG3_Enable )
				VramAssignedBGNum[screen_index] = 3;
			
			else
				#ifndef X432R_SIMPLIFIED_SPRITEDETECTION
				VramAssignedBGNum[screen_index] = 0xFF;
				#else
				VramAssignedBGNum[screen_index] = ( LayerPriority[screen_index][2] <= LayerPriority[screen_index][3] ) ? 3 : 2;		// �D��x�̒Ⴂ���Ɋ��蓖�Ă��Ă���Ƒz��
				#endif
			
			return false;
		}
		
		void ClearMainGpuBuffers()
		{
			#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
			MainGpuUnupdatedFrameCount = -1;		// ��\���t���O���Z�b�g
			#endif
			
			PolygonCount = 0;
			ExistsMainGpuBG03D = false;
			
			memset( MainGpuHighResolutionBuffer, 0, sizeof(MainGpuHighResolutionBuffer) );
			#ifndef X432R_SIMPLIFIED_SPRITEDETECTION
			memset( MainGpuDownscaledBuffer, 0, sizeof(MainGpuDownscaledBuffer) );
			#endif
//			memset( BackgroundBuffer, 0, sizeof(BackgroundBuffer) );
//			memset( ForegroundBuffer, 0, sizeof(ForegroundBuffer) );
			
			#ifndef X432R_LAYERNUMBUFFER_DISABLED
//			memset( LayerNumBuffer, 0xFF, sizeof(LayerNumBuffer) );
//			memset( PriorityBuffer, 0xFF, sizeof(PriorityBuffer) );
			#endif
		}
		
		void ClearVramBuffers(const u32 vram_block)
		{
			if(vram_block > 3) return;
			
			VramPurpose[vram_block] = VramConfiguration::Purpose::OFF;
			
			if( !VramIsValid[vram_block] ) return;
			
			memset( VramHighResolutionBuffer[vram_block], 0, sizeof( VramHighResolutionBuffer[vram_block] ) );
			#ifndef X432R_SIMPLIFIED_SPRITEDETECTION
			memset( VramDownscaledBuffer[vram_block], 0, sizeof( VramDownscaledBuffer[vram_block] ) );
			#endif
			#ifndef X432R_NEW_DISPCAPTURE_TEST
			memset( VramBackgroundBuffer[vram_block], 0, sizeof( VramBackgroundBuffer[vram_block] ) );
			memset( VramForegroundBuffer[vram_block], 0, sizeof( VramForegroundBuffer[vram_block] ) );
			
			VramContains2DData[vram_block] = false;
//			Vram3DOpacity[vram_block] = 0xFF;
			#endif
			
			VramIsValid[vram_block] = false;
			
			#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
			VramUnupdatedFrameCount[vram_block] = -1;
			#endif
		}
		
		inline bool IsDisplayCaptureInvalid()
		{
			X432R_RENDER_MAGNIFICATION_CHECK();
			
			if(renderMagnification == 1) return true;
			if(MainGpuDisplayCapture.enabled == FALSE) return true;
			
			if( (MainGpuDisplayCapture.capx != DISPCAPCNT::_256) || (MainGpuDisplayCapture.capy != 192) ) return true;
			if( (MainGpuDisplayCapture.writeOffset != 0) || (MainGpuDisplayCapture.readOffset != 0) ) return true;
			
			switch(MainGpuDisplayCapture.capSrc)
			{
				case 0:
					#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
					if( !Is3DVisible<false>() ) return true;
					#endif
					break;
				
				case 1:
					{
						if(MainGpuDisplayCapture.srcB == 1) return true;
						
						const u8 vram_block = MainGpuDisplayCapture.readBlock;
						
//						if( (vram_block > 3) || !VramIsValid[vram_block] ) return true;
						if(vram_block > 3) return true;
					}
					break;
				
				default:
					{
						#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
						if( !Is3DVisible<false>() ) return true;
						#endif
						
						if(MainGpuDisplayCapture.srcB == 1) return true;		// temp
						
						const u8 vram_block = MainGpuDisplayCapture.readBlock;
						
//						if( (vram_block > 3) || !VramIsValid[vram_block] ) return true;
						if(vram_block > 3) return true;
					}
					break;
			}
			
			return false;
		}
		
		void UpdateMasterBrightness()
		{
//			const u32 mainscreen_index = MainScreen.offset ? 1 : 0;
			const NDS_Screen *screen;
			
			for(u32 i = 0; i < 2; ++i)
			{
//				screen = (i == mainscreen_index) ? &MainScreen : &SubScreen;
				screen = (i == MainScreenIndex) ? &MainScreen : &SubScreen;
				
				if(screen->gpu->MasterBrightFactor <= 2)
				{
					MasterBrightness[i] = 0;	// �H�Ƀt�F�[�h���ʂ̌��MasterBrightness��0�Ƀ��Z�b�g����Ă��Ȃ��ꍇ������̂�2�ȉ��𖳎��i�Č��x�͒ቺ����j
					continue;
				}
				
				s32 alpha = (s32)std::min<u32>(screen->gpu->MasterBrightFactor * 16, 0xFF);
				
				switch(screen->gpu->MasterBrightMode)
				{
					case 1:		// bright up
						break;
					
					case 2:		// bright down
						alpha = -alpha;
						break;
					
					default:
						alpha = 0;
						break;
				}
				
				MasterBrightness[i] = alpha;
			}
		}
		
		#ifdef X432R_NEW_DISPCAPTURE_TEST
		void GetHighResolutionBufferSource(u32 **highreso_buffers, u32 &buffers_count)
		{
			std::multimap< u8, u32 *, std::greater<u8> > buffers;
			u8 vram_block, layer_num, screen_index, priority;
			
			if(ExistsMainGpuBG03D)
			{
				priority = LayerPriority[MainScreenIndex][0];
				buffers.insert( std::make_pair(priority, MainGpuHighResolutionBuffer) );
			}
			
			for(u32 i = 0; i < 4; ++i)
			{
				if( !VramIsValid[i] ) continue;
				
				if(i == VramBlockMainScreen)
				{
					screen_index = MainScreenIndex;
					priority = 0;
				}
				else
				{
					switch( VramPurpose[i] )
					{
						case VramConfiguration::Purpose::ABG:
							if( (VramBlockMainScreen <= 3) || !ExistsVramAssignedBG[MainScreenIndex] ) continue;
							
							layer_num = VramAssignedBGNum[MainScreenIndex];
							
							if(layer_num > 3) continue;
							
							screen_index = MainScreenIndex;
							priority = LayerPriority[MainScreenIndex][layer_num];
							
	//						if(priority == 0xFF)
	//							priority = 0;
							
							break;
						
						case VramConfiguration::Purpose::AOBJ:
							if( (VramBlockMainScreen <= 3) || !ExistsVramAssignedOBJ[MainScreenIndex] ) continue;
							
							screen_index = MainScreenIndex;
							priority = VramAssignedOBJPriority[MainScreenIndex];
							
							if(priority == 0xFF)
								priority = 0;
							
							break;
						
						case VramConfiguration::Purpose::BBG:
							if( !ExistsVramAssignedBG[SubScreenIndex] ) continue;
							
							layer_num = VramAssignedBGNum[SubScreenIndex];
							
							if(layer_num > 3) continue;
							
							screen_index = SubScreenIndex;
							priority = LayerPriority[SubScreenIndex][layer_num];
							
	//						if(priority == 0xFF)
	//							priority = 0;
							
							break;
						
						case VramConfiguration::Purpose::BOBJ:
							if( !ExistsVramAssignedOBJ[SubScreenIndex] ) continue;
							
							screen_index = SubScreenIndex;
							priority = VramAssignedOBJPriority[SubScreenIndex];
							
							if(priority == 0xFF)
								priority = 0;
							
							break;
						
						default:
							continue;
					}
				}
				
				buffers.insert( std::make_pair( priority, VramHighResolutionBuffer[i] ) );
			}
			
			memset( highreso_buffers, 0, sizeof(u32 *) * 3 );
			
			std::multimap<u8, u32 *>::iterator iterator, end_iterator;
			u32 count;
			
			iterator = buffers.begin();
			end_iterator = buffers.end();
			count = buffers.size();
			
			assert(count <= 3);
			
			buffers_count = count;
			
			for(u32 j = 0; iterator != end_iterator; ++j, ++iterator)
			{
				highreso_buffers[j] = (*iterator).second;
			}
		}
		
		template <u8 CAPTURESOURCE_A, u8 CAPTURESOURCE_B, bool DEBUG_MODE>
		void GetFinalBuffer(u32 *final_buffer, const u8 screen_index, const u32 * const *highreso_buffers, const u32 buffers_count, const u8 vram_writeblock, const u8 vram_readblock)
		{
			X432R_RENDER_MAGNIFICATION_CHECK();
			
			if(renderMagnification == 1) return;
			
			
			const u16 *source_buffer = (u16 *)video.srcBuffer;
			u32 *background_buffer, *foreground_buffer;
			
			static const u32 mag_minus_one = RENDER_MAGNIFICATION - 1;
			u32 downscaled_y;
	//		u32 downscaled_index;
			u32 screen_offset, highreso_index;
			u32 buffer_count;
			RGBA8888 color_rgba8888;
			
	//		s32 BG03D_horizontal_offset = frontBuffers.LayerHorizontalOffset[0] * RENDER_MAGNIFICATION;
			
			
			screen_offset = screen_index * 256 * 192;
			final_buffer += renderWidth * renderHeight;
			
			buffer_count = sourceBufferCount[screen_index];
			
			
			// Background2D, HighResolution3D, Foreground2D���������č��𑜓x�o�b�t�@�ɏ�������
			// DispCapture�������Ɏ��s����
			if(buffer_count == 0)
			{
				for( u32 y = 0; y < (192 * RENDER_MAGNIFICATION); ++y )
				{
					source_buffer = (u16 *)video.srcBuffer + screen_offset + ( (y / RENDER_MAGNIFICATION) * 256 );
					
					for( u32 x = 0; x < (256 * RENDER_MAGNIFICATION); ++x, ++final_buffer )
					{
						color_rgba8888 = (u32)RGB15TO24_REVERSE(*source_buffer) | 0xFF000000;
						
						// DispCapture & Blending
/*						if(CAPTURESOURCE_B == 0xFF)
						{
							// todo
						}
						else if(CAPTURESOURCE_A == 0xFF)
						{
							// todo
						}
						else
						{
							// todo
						}
*/						
						*final_buffer = color_rgba8888.Color;
						
						if( (x % renderMagnification) == mag_minus_one )
							++source_buffer;
						
					}
				}
			}
			else
			{
				for( u32 y = 0; y < (192 * RENDER_MAGNIFICATION); ++y )
				{
					downscaled_y = (y / RENDER_MAGNIFICATION) * 256;
					
					source_buffer = (u16 *)video.srcBuffer + screen_offset + downscaled_y;
					background_buffer = BackgroundBuffer[i] + downscaled_y;
					foreground_buffer = ForegroundBuffer[i] + downscaled_y;
					
					for( u32 x = 0; x < (256 * RENDER_MAGNIFICATION); ++x, ++final_buffer )
					{
	//					downscaled_index = downscaled_y + (x / RENDER_MAGNIFICATION);
						
						highreso_index = (y * 256 * RENDER_MAGNIFICATION) + x;
						
						color_rgba8888 = 0;
						
						// Background2D
						if( !DEBUG_MODE || showBackground2D )
						{
							#if 1
							color_rgba8888 = *background_buffer;
							
							if(color_rgba8888.A == 0)
								color_rgba8888 = (u32)RGB15TO24_REVERSE(*source_buffer) | 0xFF000000;
							#else
							// debug
							color_rgba8888 = (u32)RGB15TO24_REVERSE(*source_buffer) | 0xFF000000;
							#endif
						}
						
						// HighResolution3D
						if( !DEBUG_MODE || showHighResolution3D )
						{
							for(u32 j = 0; j < buffer_count; ++j)
							{
								color_rgba8888 = RGBA8888::AlphaBlend( sourceBuffer_HighResolution[i][j][highreso_index], color_rgba8888 );
							}
						}
						
						// Foreground2D
						if( !DEBUG_MODE || showForeground2D )
						{
							#if 1
							color_rgba8888 = RGBA8888::AlphaBlend(*foreground_buffer, color_rgba8888);
							#else
							// debug
							layer_num = frontBuffers.LayerNumBuffer[i][downscaled_index];
							
							switch(layer_num)
							{
								case 0:		color_rgba8888 = RGBA8888::AlphaBlend(0x7F00FF00, color_rgba8888);							break;	// BG0
								case 4:		color_rgba8888 = RGBA8888::AlphaBlend(0x7FFF0000, color_rgba8888);							break;	// OBJ
								case 5:		color_rgba8888 = RGBA8888::AlphaBlend(0x7FFF00FF, color_rgba8888);							break;	// Backdrop
								default:	color_rgba8888 = RGBA8888::AlphaBlend( (layer_num << 30) | 0x0000FF, color_rgba8888 );		break;	// BG1�`3
							}
							#endif
						}
						
						// DispCapture & Blending
						if(CAPTURESOURCE_B == 0xFF)
						{
							// todo
						}
						else if(CAPTURESOURCE_A == 0xFF)
						{
							// todo
						}
						else
						{
							// todo
						}
						
						
						*final_buffer = color_rgba8888.Color;
						
						if( (x % renderMagnification) == mag_minus_one )
						{
							++source_buffer;
							++background_buffer;
							++foreground_buffer;
						}
					}
				}
			}
			
//			VramIsValid[vram_writeblock] = true;
//			VramUnupdatedFrameCount[vram_writeblock] = 0;
		}
		#endif
		
		
		public:
		
		void Clear()
		{
			memset( this, 0, sizeof(HighResolutionFramebuffers) );
			
			#ifndef X432R_LAYERNUMBUFFER_DISABLED
			memset( LayerNumBuffer, 0xFF, sizeof(LayerNumBuffer) );
			memset( PriorityBuffer, 0xFF, sizeof(PriorityBuffer) );
			#endif
			
			VramBlockMainScreen = 0xFF;
			memset( VramBlockBG, 0xFF, sizeof(VramBlockBG) );
			memset( VramBlockOBJ, 0xFF, sizeof(VramBlockOBJ) );
			memset( VramAssignedBGNum, 0xFF, sizeof(VramAssignedBGNum) );
			memset( VramAssignedOBJPriority, 0xFF, sizeof(VramAssignedOBJPriority) );
			
			MainScreenIndex = 0;
			SubScreenIndex = 1;
			DisplayCaptureBlendingRatio = 0xFF;
			
			#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
			MainGpuUnupdatedFrameCount = -1;
			#endif
			#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
			VramUnupdatedFrameCount[0] = -1;
			VramUnupdatedFrameCount[1] = -1;
			VramUnupdatedFrameCount[2] = -1;
			VramUnupdatedFrameCount[3] = -1;
			#endif
		}
		
		HighResolutionFramebuffers()
		{
			Clear();
		}
		
		#ifndef X432R_NEW_DISPCAPTURE_TEST
		HighResolutionFramebuffers & operator=(const HighResolutionFramebuffers &source)
		{
			MainScreenIndex = source.MainScreenIndex;
			SubScreenIndex = source.SubScreenIndex;
			MainGpuDisplayMode = source.MainGpuDisplayMode;
//			MainGpuClearColor = source.MainGpuClearColor;
//			DisplayControl[0] = source.DisplayControl[0];
//			DisplayControl[1] = source.DisplayControl[1];
//			MainGpuBG03DEnabled = source.MainGpuBG03DEnabled;
//			MainGpuDisplayCapture = source.MainGpuDisplayCapture;
//			DisplayCaptureBlendingRatio = source.DisplayCaptureBlendingRatio;
			
			memcpy( VramPurpose, source.VramPurpose, sizeof(VramPurpose) );
			memcpy( VramIsValid, source.VramIsValid, sizeof(VramIsValid) );
			memcpy( VramContains2DData, source.VramContains2DData, sizeof(VramContains2DData) );
//			memcpy( Vram3DOpacity, source.Vram3DOpacity, sizeof(Vram3DOpacity) );
			
			VramBlockMainScreen = source.VramBlockMainScreen;
			
			memcpy( VramBlockBG, source.VramBlockBG, sizeof(VramBlockBG) );
			memcpy( VramBlockOBJ, source.VramBlockOBJ, sizeof(VramBlockOBJ) );
			memcpy( VramAssignedBGNum, source.VramAssignedBGNum, sizeof(VramAssignedBGNum) );
			memcpy( VramAssignedOBJPriority, source.VramAssignedOBJPriority, sizeof(VramAssignedOBJPriority) );
			
			memcpy( MasterBrightness, source.MasterBrightness, sizeof(MasterBrightness) );
			memcpy( LayerPriority, source.LayerPriority, sizeof(LayerPriority) );
			
//			PolygonCount = source.PolygonCount;
			
			#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
			MainGpuUnupdatedFrameCount = source.MainGpuUnupdatedFrameCount;
			#endif
			#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
//			memcpy( VramUnupdatedFrameCount, source.VramUnupdatedFrameCount, sizeof(VramUnupdatedFrameCount) );
			#endif
			
			ExistsMainGpuBG03D = source.ExistsMainGpuBG03D;
			
			memcpy( ExistsVramAssignedBG, source.ExistsVramAssignedBG, sizeof(ExistsVramAssignedBG) );
			memcpy( ExistsVramAssignedOBJ, source.ExistsVramAssignedOBJ, sizeof(ExistsVramAssignedOBJ) );
			
//			memcpy( LayerHorizontalOffset, source.LayerHorizontalOffset, sizeof(LayerHorizontalOffset) );
//			memcpy( LayerVerticalOffset, source.LayerVerticalOffset, sizeof(LayerVerticalOffset) );
			
			
			const u32 highreso_size = sizeof(u32) * renderWidth * renderHeight;
			VramConfiguration::Purpose vram_purpose;
			
			#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
			if( (MainGpuDisplayMode == 1) && Is3DVisible<false>() && ExistsMainGpuBG03D )
				memcpy(MainGpuHighResolutionBuffer, source.MainGpuHighResolutionBuffer, highreso_size);
			else
			{
				MainGpuUnupdatedFrameCount = -1;
				ExistsMainGpuBG03D = false;
			}
			#else
			if( (MainGpuDisplayMode == 1) && ExistsMainGpuBG03D )
				memcpy(MainGpuHighResolutionBuffer, source.MainGpuHighResolutionBuffer, highreso_size);
			else
				ExistsMainGpuBG03D = false;
			#endif
			
			for(int i = 0; i < 4; ++i)
			{
				if( !VramIsValid[i] ) continue;
				
				vram_purpose = VramPurpose[i];
				
				switch(vram_purpose)
				{
					case VramConfiguration::Purpose::ABG:
						if( ( (MainGpuDisplayMode == 2) && (VramBlockMainScreen <= 3) ) || !ExistsVramAssignedBG[MainScreenIndex] )
						{
							VramPurpose[i] = VramConfiguration::Purpose::OFF;
							VramAssignedBGNum[MainScreenIndex] = 0xFF;
							ExistsVramAssignedBG[MainScreenIndex] = false;
							VramIsValid[i] = false;
							continue;
						}
						break;
					
					case VramConfiguration::Purpose::AOBJ:
						if( ( (MainGpuDisplayMode == 2) && (VramBlockMainScreen <= 3) ) || !ExistsVramAssignedOBJ[MainScreenIndex] )
						{
							VramPurpose[i] = VramConfiguration::Purpose::OFF;
							VramAssignedOBJPriority[MainScreenIndex] = 0xFF;
							ExistsVramAssignedOBJ[MainScreenIndex] = false;
							VramIsValid[i] = false;
							continue;
						}
						break;
					
					case VramConfiguration::Purpose::BBG:
						if( !ExistsVramAssignedBG[SubScreenIndex] )
						{
							VramPurpose[i] = VramConfiguration::Purpose::OFF;
							VramAssignedBGNum[SubScreenIndex] = 0xFF;
							VramIsValid[i] = false;
							continue;
						}
						break;
					
					case VramConfiguration::Purpose::BOBJ:
						if( !ExistsVramAssignedOBJ[SubScreenIndex] )
						{
							VramPurpose[i] = VramConfiguration::Purpose::OFF;
							VramAssignedOBJPriority[SubScreenIndex] = 0xFF;
							VramIsValid[i] = false;
							continue;
						}
						break;
					
					case VramConfiguration::Purpose::LCDC:
						if( (MainGpuDisplayMode != 2) || (VramBlockMainScreen > 3) )
						{
							VramPurpose[i] = VramConfiguration::Purpose::OFF;
							VramIsValid[i] = false;
							VramBlockMainScreen = 0xFF;
							continue;
						}
						break;
					
					default:
						VramIsValid[i] = false;
						continue;
				}
				
				memcpy(VramHighResolutionBuffer[i], source.VramHighResolutionBuffer[i], highreso_size);
			}
			
			
			memcpy( BackgroundBuffer, source.BackgroundBuffer, sizeof(BackgroundBuffer) );
			memcpy( ForegroundBuffer, source.ForegroundBuffer, sizeof(ForegroundBuffer) );
			
			#ifndef X432R_LAYERNUMBUFFER_DISABLED
//			memcpy( LayerNumBuffer, source.LayerNumBuffer, sizeof(LayerNumBuffer) );
			#endif
			
			return *this;
		}
			#endif
		
		
		void UpdateGpuParams()
		{
			MainScreenIndex = MainScreen.offset ? 1 : 0;
			SubScreenIndex = MainScreenIndex ? 0 : 1;
			MainGpuDisplayMode = MainScreen.gpu->dispMode;
			
			DisplayControl[MainScreenIndex] = (_DISPCNT)(MainScreen.gpu->dispx_st)->dispx_DISPCNT.bits;
			DisplayControl[SubScreenIndex] = (_DISPCNT)(SubScreen.gpu->dispx_st)->dispx_DISPCNT.bits;
			
			UpdateMasterBrightness();
			
			VramBlockMainScreen = 0xFF;
			memset( VramBlockBG, 0xFF, sizeof(VramBlockBG) );
			memset( VramBlockOBJ, 0xFF, sizeof(VramBlockOBJ) );
			memset( VramAssignedBGNum, 0xFF, sizeof(VramAssignedBGNum) );
			memset( VramAssignedOBJPriority, 0xFF, sizeof(VramAssignedOBJPriority) );
			
			
			ExistsMainGpuBG03D = false;
			
			memset( ExistsVramAssignedBG, 0, sizeof(ExistsVramAssignedBG) );
			memset( ExistsVramAssignedBG, 0, sizeof(ExistsVramAssignedBG) );
			
			
			MainGpuDisplayCapture = MainScreen.gpu->dispCapCnt;
			
			if(MainGpuDisplayCapture.val & 0x80000000)
			{
				MainGpuDisplayCapture.enabled = TRUE;
				DisplayCaptureBlendingRatio = (u8)std::min<u32>(MainGpuDisplayCapture.EVA * 16, 0xFF);
			}
/*			else
			{
				MainGpuDisplayCapture.enabled = FALSE;
				DisplayCaptureBlendingRatio = 0xFF;
			}
*/			
			
			bool vrambg_main = false;
			bool vrambg_sub = false;
			VramConfiguration::Purpose purpose;
			
			for(u32 i = 0; i < 4; ++i)
			{
				LayerPriority[MainScreenIndex][i] = MainScreen.gpu->bgPrio[i];
				LayerPriority[SubScreenIndex][i] = SubScreen.gpu->bgPrio[i];
				
/*				LayerHorizontalOffset[MainScreenIndex][i] = MainScreen.gpu->getHOFS(i);
//				LayerVerticalOffset[MainScreenIndex][i] = (i != 0) ? MainScreen.gpu->getVOFS(i) : 0;	// BG0_3D�ł�VOFS����
				LayerVerticalOffset[MainScreenIndex][i] = MainScreen.gpu->getVOFS(i);
				
				LayerHorizontalOffset[SubScreenIndex][i] = MainScreen.gpu->getHOFS(i);
				LayerVerticalOffset[SubScreenIndex][i] = MainScreen.gpu->getVOFS(i);
*/				
				
				purpose = vramConfiguration.banks[i].purpose;
				
				switch(purpose)
				{
					case VramConfiguration::Purpose::ABG:
						if( !VramIsValid[i] || UpdateVramAssignedBGNum(DisplayControl + MainScreenIndex, MainScreenIndex) ) break;
						
						VramPurpose[i] = purpose;
						VramBlockBG[MainScreenIndex] = i;
						continue;
					
					case VramConfiguration::Purpose::AOBJ:
						if( !VramIsValid[i] || !(bool)DisplayControl[MainScreenIndex].OBJ_Enable ) break;
						
						VramPurpose[i] = purpose;
						VramBlockOBJ[MainScreenIndex] = i;
						continue;
					
					case VramConfiguration::Purpose::BBG:
						if( !VramIsValid[i] || UpdateVramAssignedBGNum(DisplayControl + SubScreenIndex, SubScreenIndex) ) break;
						
						VramPurpose[i] = purpose;
						VramBlockBG[SubScreenIndex] = i;
						continue;
					
					case VramConfiguration::Purpose::BOBJ:
						if( !VramIsValid[i] || !(bool)DisplayControl[SubScreenIndex].OBJ_Enable ) break;
						
						VramPurpose[i] = purpose;
						VramBlockOBJ[SubScreenIndex] = i;
						continue;
					
					case VramConfiguration::Purpose::LCDC:
						VramPurpose[i] = purpose;
						
						if( !VramIsValid[i] || (MainGpuDisplayMode != 2) || (i != MainScreen.gpu->vramBlock) ) continue;
						
						VramBlockMainScreen = i;
						continue;
				}
				
				ClearVramBuffers(i);
			}
		}
		
		void Update3DParams(const u32 clearcolor, const u32 polygon_count)
		{
			MainGpuClearColor = clearcolor;
			PolygonCount = polygon_count;
			
			#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
			if(PolygonCount > 0)		// 3D�����_�������s����Ă��Ă�3D���`�悳��Ă��Ȃ��ꍇ�����邽�߃|���S�������`�F�b�N
				MainGpuUnupdatedFrameCount = 0;
			#endif
		}
		
		
/*		u8 GetVramWriteBlockIndex() const
		{
			if( (MainGpuDisplayCapture.enabled == FALSE) || (MainGpuDisplayCapture.srcA != 1) ) return 0xFF;		// �L���v�`���\�[�X��3D only�̎��̂ݗL��
			
			const u8 vram_block = MainGpuDisplayCapture.writeBlock;
			
			if( (vram_block > 3) || (VramPurpose[vram_block] != VramConfiguration::Purpose::LCDC) ) return 0xFF;
			
			return vram_block;
		}
*/		
		u8 GetVramReadBlockIndex() const
		{
//			if( (MainGpuDisplayCapture.enabled == FALSE) || (MainGpuDisplayCapture.capSrc < 2) || (MainGpuDisplayCapture.capSrc > 3) || (MainGpuDisplayCapture.srcB != 0) ) return 0xFF;
			if( (MainGpuDisplayCapture.capSrc < 2) || (MainGpuDisplayCapture.capSrc > 3) || (MainGpuDisplayCapture.srcB != 0) ) return 0xFF;
			
			const u32 vram_block = MainGpuDisplayCapture.readBlock;
			
			if( (vram_block > 3) || (VramPurpose[vram_block] != VramConfiguration::Purpose::LCDC) ) return 0xFF;
			
			return vram_block;
		}
		
		
		#if !defined(X432R_BUFFERRESETDELAY_MAIN_DISABLED) || !defined(X432R_BUFFERRESETDELAY_VRAM_DISABLED)
		// ��莞��3D�����_�����O���s���Ȃ������ꍇ�A���𑜓x3D���\���ɂ���
		// ��\���ɂ���^�C�~���O����������ƍ��𑜓x3D�\�����s�K�v��ON/OFF����邽�߂�����̌����ɂȂ�
		void Update3DVisibility(const u32 frameskip_rate, const bool fast_forward)
		{
			static s32 fastforward_delay = 0;
			
			if(fast_forward)
				fastforward_delay = BufferResetDelay_FastForward;
			
			else if(fastforward_delay > 0)
				--fastforward_delay;
			
			s32 delay = fastforward_delay + frameskip_rate;
			
			#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
			if(MainGpuUnupdatedFrameCount >= 0)
			{
				if( MainGpuUnupdatedFrameCount <= (BufferResetDelay_MainGpu + delay) )
					++MainGpuUnupdatedFrameCount;
				
				else
					ClearMainGpuBuffers();
			}
			#endif
			
			#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
			delay += BufferResetDelay_Vram;
			
			for(u32 i = 0; i < 4; ++i)
			{
				if( VramUnupdatedFrameCount[i] < 0 ) continue;
				
				if( VramUnupdatedFrameCount[i] <= delay )
				{
					++VramUnupdatedFrameCount[i];
					continue;
				}
				
				ClearVramBuffers(i);	// ��莞�ԍX�V����Ȃ�����VRAM���N���A
			}
			#endif
		}
		#endif
		
		#ifndef X432R_BUFFERRESETDELAY_MAIN_DISABLED
		template <bool CHECK_VRAM>
		inline bool Is3DVisible() const
		{
			X432R_RENDER_MAGNIFICATION_CHECK();
			
			if(renderMagnification == 1) return false;
			
			if( CHECK_VRAM && ( VramIsValid[0] || VramIsValid[1] || VramIsValid[2] || VramIsValid[3] ) ) return true;
			
			return (MainGpuUnupdatedFrameCount >= 0);
		}
		#endif
		
		
		#ifndef X432R_NEW_DISPCAPTURE_TEST
		void ExecDisplayCapture()
		{
			if( IsDisplayCaptureInvalid() ) return;
			
//			MainGpuDisplayCapture.enabled = FALSE;
			
			const u8 vram_block = MainGpuDisplayCapture.writeBlock;
			
			if( (vram_block > 3) || ( VramPurpose[vram_block] != VramConfiguration::Purpose::LCDC ) ) return;
			
//			memcpy( VramHighResolutionBuffer[vram_block], MainGpuHighResolutionBuffer, sizeof( VramHighResolutionBuffer[vram_block] ) );
			memcpy( VramHighResolutionBuffer[vram_block], MainGpuHighResolutionBuffer, sizeof(u32) * renderWidth * renderHeight );
			
			#ifndef X432R_SIMPLIFIED_SPRITEDETECTION
			memcpy( VramDownscaledBuffer[vram_block], MainGpuDownscaledBuffer, sizeof( VramDownscaledBuffer[vram_block] ) );
			#endif
			
			if(MainGpuDisplayCapture.srcA == 0)
			{
				memcpy( VramBackgroundBuffer[vram_block], BackgroundBuffer[MainScreenIndex], sizeof( VramBackgroundBuffer[vram_block] ) );
				memcpy( VramForegroundBuffer[vram_block], ForegroundBuffer[MainScreenIndex], sizeof( VramForegroundBuffer[vram_block] ) );
				VramContains2DData[vram_block] = true;
			}
			else
			{
//				memset( VramBackgroundBuffer[vram_block], 0, sizeof( VramBackgroundBuffer[vram_block] ) );
//				memset( VramForegroundBuffer[vram_block], 0, sizeof( VramForegroundBuffer[vram_block] ) );
				VramContains2DData[vram_block] = false;
			}
			
			VramIsValid[vram_block] = true;
			
			#ifndef X432R_BUFFERRESETDELAY_VRAM_DISABLED
			VramUnupdatedFrameCount[vram_block] = 0;
			#endif
		}
		#else
		template <bool DEBUG_MODE>
		void GetFinalBuffer(u32 *final_buffer)
		{
			assert(final_buffer != NULL);
			
			bool dispcapture_enabled = IsDisplayCaptureInvalid();
			u8 vram_writeblock = MainGpuDisplayCapture.writeBlock;
			u8 vram_readblock = MainGpuDisplayCapture.readBlock;
			
			if(dispcapture_enabled)
			{
				if( (vram_writeblock > 3) || ( VramPurpose[vram_writeblock] != VramConfiguration::Purpose::LCDC ) )
				{
					dispcapture_enabled = false;
					vram_writeblock = 0xFF;
				}
				
				if( (vram_readblock > 3) || ( VramPurpose[vram_readblock] != VramConfiguration::Purpose::LCDC ) )
				{
					dispcapture_enabled = false;
					vram_readblock = 0xFF;
				}
			}
			
			
			u32 *highreso_buffers[3];
			u32 buffers_count;
			
			for(u32 i = 0; i < 2; ++i)
			{
				GetHighResolutionBufferSource(highreso_buffers, buffers_count);
				
				
				if( (i == MainScreenIndex) && dispcapture_enabled )
				{
					switch(MainGpuDisplayCapture.capSrc)
					{
						case 0:		// srcA
							if(MainGpuDisplayCapture.srcA == 0)
								GetFinalBuffer<0, 0xFF, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
							else
								GetFinalBuffer<1, 0xFF, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
							
							continue;
						
						case 1:		// srcB
							if(MainGpuDisplayCapture.srcB == 0)
								GetFinalBuffer<0xFF, 0, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
							else
								GetFinalBuffer<0xFF, 1, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
							
							continue;
						
						default:	// A+B
							if(MainGpuDisplayCapture.srcA == 0)
							{
								if(MainGpuDisplayCapture.srcB == 0)
									GetFinalBuffer<0, 0, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
								else
									GetFinalBuffer<0, 1, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
							}
							else
							{
								if(MainGpuDisplayCapture.srcB == 0)
									GetFinalBuffer<1, 0, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
								else
									GetFinalBuffer<1, 1, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, vram_writeblock, 0xFF);
							}
							continue;
					}
				}
				
				GetFinalBuffer<0xFF, 0xFF, DEBUG_MODE>(final_buffer, i, highreso_buffers, buffers_count, 0xFF, 0xFF);
			}
		}
		
		void GetMasterBrightness(u32 *master_brightness)
		{
			assert(master_brightness != NULL);
			
			for(u32 i = 0; i < 2; ++i)
			{
				master_brightness[i] = MasterBrightness[i];
			}
		}
		#endif
	};
	
	extern HighResolutionFramebuffers backBuffers;
}
#endif
//<---CUSTOM---


#endif

